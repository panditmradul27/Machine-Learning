import cv2
import numpy as np

Red_cupss = cv2.CascadeClassifier('Red_cups.xml')

carss = cv2.CascadeClassifier('cars.xml')

Bus_fronts = cv2.CascadeClassifier('Bus_front.xml')

WallClocks = cv2.CascadeClassifier('WallClock.xml')

two_wheelers = cv2.CascadeClassifier('two_wheeler.xml')

bananas = cv2.CascadeClassifier('banana.xml')

Football_cascades = cv2.CascadeClassifier('Football_cascade.xml')

haarcascade_fullbodys = cv2.CascadeClassifier('haarcascade_fullbody.xml')

haarcascade_smiles = cv2.CascadeClassifier('haarcascade_smile.xml')

Phone_Cascades = cv2.CascadeClassifier('Phone_Cascade.xml')






if Red_cupss.empty():
    raise IOError('Unable to Red_cups.xml file')

if carss.empty():
    raise IOError('Unable to load cars.xml file')

if Bus_fronts.empty():
    raise IOError('Unable to load Bus_front.xml file')

if WallClocks.empty():
    raise IOError('Unable to load WallClock.xml file')

if two_wheelers.empty():
    raise IOError('Unable to load two_wheeler.xml file')

if bananas.empty():
    raise IOError('Unable to load banana.xml file')

if Football_cascades.empty():
    raise IOError('Unable to load Football_cascade.xml file')

if haarcascade_fullbodys.empty():
    raise IOError('Unable to load haarcascade_fullbody.xml file')

if haarcascade_smiles.empty():
    raise IOError('Unable to load haarcascade_smile.xml file')

if Phone_Cascades.empty():
    raise IOError('Unable to load Phone_Cascade.xml file')



capture = cv2.VideoCapture(0)

while True:
    ret, capturing = capture.read()
    x,y,w,h=0,0,0,0

    resize_frame = cv2.resize(capturing, None, fx=0.5, fy=0.5,interpolation=cv2.INTER_AREA)
    gray = cv2.cvtColor(resize_frame, cv2.COLOR_BGR2GRAY)





    Red_cups = Red_cupss.detectMultiScale(gray, 1.3, 5)

    for (x,y,w,h) in Red_cups:
        #REd
        cv2.rectangle(resize_frame, (x,y), (x+w,y+h), (0,0,255), 10)
        text = "Cups"
        cv2.putText(resize_frame, text, (x, h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)


    cars = carss.detectMultiScale(gray, 1.3, 5)

    for (cars_x, cars_y, cars_w, cars_h) in cars:
        #Blue
        cv2.rectangle(resize_frame,(cars_x,cars_y),(cars_x + cars_w, cars_y + cars_h),(255,0,0),5)
        text = "Car"
        cv2.putText(resize_frame, text, (cars_x, cars_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)




    Bus_front = Bus_fronts.detectMultiScale(gray, 1.3, 5)

    for (Bus_front_x, Bus_front_y, Bus_front_w, Bus_front_h) in Bus_front:
        cv2.rectangle(resize_frame, (Bus_front_x, Bus_front_y), (Bus_front_x + Bus_front_w, Bus_front_y + Bus_front_h), (0,255,0), 5)
        text = "Bus"
        cv2.putText(resize_frame, text, (Bus_front_x, Bus_front_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)





    WallClock = WallClocks.detectMultiScale(gray, 1.3, 5)

    for (WallClock_x, WallClock_y, WallClock_w, WallClock_h) in WallClock:
        # orange
        cv2.rectangle(resize_frame, (WallClock_x, WallClock_y), (WallClock_x + WallClock_w, WallClock_y + WallClock_h), (0,165,255), 5)
        text = "Clock"
        cv2.putText(resize_frame, text, (WallClock_x, WallClock_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)



    two_wheeler = two_wheelers.detectMultiScale(gray, 1.3, 5)

    for (two_wheeler_x, two_wheeler_y, two_wheeler_w, two_wheeler_h) in two_wheeler:
        #Yellow
        cv2.rectangle(resize_frame, (two_wheeler_x, two_wheeler_y), (two_wheeler_x + two_wheeler_w, two_wheeler_y + two_wheeler_h), (0,255,255), 5)
        text = "bike"

        cv2.putText(resize_frame, text, (two_wheeler_x, two_wheeler_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)

        


    banana = bananas.detectMultiScale(gray, 1.3, 5)

    for (banana_x, banana_y, banana_w, banana_h) in banana:
        #pink
        cv2.rectangle(resize_frame, (banana_x, banana_y), (banana_x + banana_w, banana_y + banana_h), (147,20,255), 5)
        text = "banana"
        cv2.putText(resize_frame, text, (banana_x, banana_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)



    Football_cascade = Football_cascades.detectMultiScale(gray, 1.3, 5)

    for (Football_cascade_x, Football_cascade_y, Football_cascade_w, Football_cascade_h) in Football_cascade:
        #gray
        cv2.rectangle(resize_frame, (Football_cascade_x, Football_cascade_y), (Football_cascade_x + Football_cascade_w, Football_cascade_y + Football_cascade_h), (128,128,128), 5)
        text = "Clock"
        cv2.putText(resize_frame, text, (Football_cascade_x, Football_cascade_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)



    haarcascade_fullbody = haarcascade_fullbodys.detectMultiScale(gray, 1.3, 5)

    for (haarcascade_fullbody_x, haarcascade_fullbody_y, haarcascade_fullbody_w, haarcascade_fullbody_h) in haarcascade_fullbody:
        #brown
        cv2.rectangle(resize_frame, (haarcascade_fullbody_x, haarcascade_fullbody_y), (haarcascade_fullbody_x + haarcascade_fullbody_w, haarcascade_fullbody_y + haarcascade_fullbody_h), (19,69,139), 5)
        text = "Body"
        cv2.putText(resize_frame, text, (haarcascade_fullbody_x, haarcascade_fullbody_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)



    haarcascade_smile = haarcascade_smiles.detectMultiScale(gray, 1.3, 5)

    for (haarcascade_smile_x, haarcascade_smile_y, haarcascade_smile_w, haarcascade_smile_h) in haarcascade_smile:
        #marun
        cv2.rectangle(resize_frame, (haarcascade_smile_x, haarcascade_smile_y), (haarcascade_smile_x + haarcascade_smile_w, haarcascade_smile_y + haarcascade_smile_h), (0,0,128), 5)
        text = "smile"
        cv2.putText(resize_frame, text, (haarcascade_smile_x, haarcascade_smile_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)


    Phone_Cascade = Phone_Cascades.detectMultiScale(gray, 1.3, 5)

    for (Phone_Cascade_x, Phone_Cascade_y, Phone_Cascade_w, Phone_Cascade_h) in Phone_Cascade:
        #Cyan
        cv2.rectangle(resize_frame, (Phone_Cascade_x, Phone_Cascade_y), (Phone_Cascade_x + Phone_Cascade_w, Phone_Cascade_y + Phone_Cascade_h), (125,125,0), 5)
        text = "Phone"
        cv2.putText(resize_frame, text, (Phone_Cascade_x, Phone_Cascade_h), cv2.FONT_HERSHEY_SIMPLEX, 1.0, (255, 255, 255), lineType=cv2.LINE_AA)




    cv2.imshow("Real-time Detection", resize_frame)







    c = cv2.waitKey(1)
    if c == 27:
        break
capture.release()
cv2.destroyAllWindows()
